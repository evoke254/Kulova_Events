<?php

namespace BotMan\Drivers\Facebook\Exceptions;

use BotMan\BotMan\Exceptions\Base\DriverException;

class FacebookException extends DriverException
{
}
